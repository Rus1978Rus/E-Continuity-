# Reviewer Questions

1. Какая mission?
2. Какой уровень recoverability заявлен?
3. Где custody?
4. Кто operator?
5. Какие dependencies?
6. Есть ли proof testing?
7. Static proof, dynamic proof или mission proof?
8. Есть ли successor?
9. Где overclaim?
10. Какие variables отсутствуют?
11. Какие SOP можно применить?
12. Какие case maturity levels завышены?
