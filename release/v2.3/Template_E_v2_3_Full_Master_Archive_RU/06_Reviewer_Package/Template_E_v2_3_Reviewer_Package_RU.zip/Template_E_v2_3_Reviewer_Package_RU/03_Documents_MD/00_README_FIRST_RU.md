# Template E v2.3 Reviewer Package RU

Короткий targeted package для внешней проверки. Версия v2.3 - stabilization release.

## Что проверять

- компактную core formula;
- Dynamic Proof Testing;
- MVW Operational Metric;
- CASE-SPACE-001 как C-3 / C-4 candidate;
- Biobank SOP Delta;
- границы и отсутствие overclaim.
