# Biobank Delta Appendix v2.3

Template E does not replace ISBER or ISO 20387. It adds a recoverability lens.

## Template E Delta

| Element | Required practice |
| --- | --- |
| Operator != Custodian | separate storage responsibility from recovery capability |
| New-Operator Proof Test | new operator must understand metadata package without oral explanation |
| Witness Aliquot Dynamic Proof | aliquot must pass thawing / unloading / QC |
| Interpretability Audit | provenance, consent, protocol version, freeze-thaw history must be readable |
| Capability Registry | track people who can thaw/QC/interpret samples |
| Managed Sunset | define what happens when old protocol becomes obsolete |

Rule:

# Sample preservation without operator-readable metadata and witness aliquot recovery testing is physical preservation, not biological recoverability.
