# Aerospace / Operational Asset Appendix v2.3

## Focus

Static preservation does not prove dynamic recoverability.

## CASE-SPACE-001

Apollo-era propulsion hardware and rocket-engine sealing-aging literature demonstrate the general risk that static preservation does not prove dynamic recoverability. The case does not claim a verified failed restart of a specific Apollo-11 lunar module engine.

## Dynamic Return-to-Service Gate

| Risk Factor | Required Check |
| --- | --- |
| Elastomers / seals | hardness, compression set, leak test |
| Lubricants | chemical condition, viscosity, contamination |
| Pressurized circuits | hydro/pneumatic pressure proof |
| Hydraulics | cycling test |
| Fuel / oxidizer residues | corrosion inspection |
| Batteries | load test |
| Electronics | powered test under load |
| Moving parts | motion cycle test |
| Welded joints | NDT / pressure / load test |

## Reviewer questions

1. Is Activation Failure a valid failure mode in your domain?
2. Does MVW-0...MVW-5 make sense as an audit scale?
3. Which aerospace maintenance or depot standards already cover this better?
4. What primary sources should replace the current C-3/C-4 candidate evidence?
