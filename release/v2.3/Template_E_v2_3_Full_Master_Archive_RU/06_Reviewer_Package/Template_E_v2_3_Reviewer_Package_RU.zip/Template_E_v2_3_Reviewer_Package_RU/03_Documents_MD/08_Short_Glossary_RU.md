# Short Glossary v2.3

| Term | Meaning |
| --- | --- |
| Mission | целевая функция |
| Recoverability | возможность вернуть функцию / объект / capability |
| Continuity Chain | цепь, поддерживающая recoverability |
| Custody | ответственность |
| Capability | способность выполнять mission |
| Static Integrity | сохранность в покое |
| Dynamic Recoverability | способность выдержать рабочую нагрузку |
| Activation Failure | отказ при возврате к нагрузке |
| MVW | Material Viability Window |
| Proof Testing | проверка recoverability |
| Managed Sunset | управляемый вывод старой технологии |
